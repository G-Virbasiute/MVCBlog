<div class="w3-container w3-red">
<p>Oops, this is the error page.</p>
<img src="views/images/standard/_errorimage.jpg" width="150" />
<p>It looks like something went wrong :(</p>
</div>