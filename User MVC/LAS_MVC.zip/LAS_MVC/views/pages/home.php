<p>Hello there <?php echo $first_name . ' ' . $last_name; ?>!<p>
<p>The above data is present to demonstrate the utilisation of variables 
populated earlier within the page processing</p>
<p>This is the home page of the MVC Skeleton Application</p>