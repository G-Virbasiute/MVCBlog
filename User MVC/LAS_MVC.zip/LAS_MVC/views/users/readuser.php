<p>User Details:</p>

<?php 
$file = $user->profilePhoto;
if(file_exists($file)){
    $img = "<img src='$file' width='150' />";
    echo $img;
}
else
{
echo "<img src='views/images/profilepics/anon.png' width='150' />";
}

?>

<p>Username: <?php echo $user->username; ?></p>
<p>Name: <?php echo $user->name. ' '. $user->lastName; ?></p>
<p>User Type: <?php echo $user->userType; ?></p>
<p>Email: <?php echo $user->userType; ?></p>
<p>Posts:</p>
